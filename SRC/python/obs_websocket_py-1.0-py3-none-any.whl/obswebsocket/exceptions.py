class ConnectionFailure(Exception):
    pass


class MessageTimeout(Exception):
    pass


class ObjectError(Exception):
    pass
